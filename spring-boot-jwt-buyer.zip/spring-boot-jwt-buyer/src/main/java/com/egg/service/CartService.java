package com.egg.service;

import java.util.List;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerDao;
import com.egg.dao.CartDao;
import com.egg.dao.PurchaseDao;
import com.egg.dao.TransactionDao;
import com.egg.model.Buyer;
import com.egg.model.PurchaseHistory;
import com.egg.model.ShoppingCart;
import com.egg.model.Transactions;



@Service
public class CartService
{
	@Autowired
	private CartDao cartdao;
	@Autowired
	private BuyerDao buyerdao;
	@Autowired
	private TransactionDao transactiondao;
	
	@Autowired
	private PurchaseDao purchasedao;
	
	
	
	public String addcartItem(int bid, ShoppingCart cart) 
	{
		Buyer buyer=buyerdao.getOne(bid);
		cart.setBuyer(buyer);
		 cartdao.save(cart);
		 return "itemadded";
	}
	//public void deleteCartItem(int id)
	//{
		//return cartdao.deleteCartItem(id);
	//}
	public void deleteById(int bid) 
	{
		 cartdao.deleteById(bid);
	}
	public List<ShoppingCart> getCartItembyId(int bid) {
		
		return cartdao.findAll();
	}
	public void deleteAllCart() {
		cartdao.deleteAll();
	}
	public ShoppingCart updatecart(Integer cid, ShoppingCart cart)
	{
	
		Optional<ShoppingCart> c=cartdao.findById(cid);
		ShoppingCart cart1=null;
		if(c.isPresent())
		{
			cart1=c.get();
			cart1.setNumberofitems(cart.getNumberofitems());
			return cartdao.save(cart1);	
		}
		return null;
	}
	
	public void checkout(int bid,Transactions transactions)
	{
		Optional<Buyer> buyer=buyerdao.findById(bid);
		PurchaseHistory purchasehistory=null;
		//Transactions transactions=null;
		
		List<ShoppingCart> getAllitems=cartdao.getAllCartitems(bid);
		transactions=new Transactions();
		
		transactions.setBuyer(buyer.get());
		transactions.setRemarks(transactions.getRemarks());
		transactions.setTransactionType(transactions.getTransactionType());
		transactiondao.save(transactions);
		
		for(ShoppingCart cart:getAllitems)
		{
			purchasehistory=new PurchaseHistory();
			purchasehistory.setBuyer(buyer.get());
			purchasehistory.setNumberOfItems(cart.getNumberofitems());
			purchasehistory.setRemarks(transactions.getRemarks());
			purchasedao.save(purchasehistory);
			cartdao.delete(cart);
			
			
		}
		
		
		
		
	}

	
	
	
	

	
	
	
		
	}

	


