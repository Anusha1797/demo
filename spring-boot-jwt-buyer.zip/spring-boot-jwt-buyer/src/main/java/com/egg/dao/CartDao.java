package com.egg.dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.egg.model.Buyer;
import com.egg.model.ShoppingCart;


@Repository
public interface CartDao extends JpaRepository<ShoppingCart,Integer> 
{
	ShoppingCart save(Buyer buyer);
    @Query(value="SELECT * FROM shopping_cart where buyer_key=:bid",nativeQuery=true)
	List<ShoppingCart> getAllCartitems(int bid);
}

