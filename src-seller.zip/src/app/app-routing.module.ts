import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddSellerComponent } from './add-seller/add-seller.component';
import { AddItemComponent } from './add-item/add-item.component';
import { ProductsListComponent } from './products-list/products-list.component';
import { LoginComponent } from './login/login.component';



const routes: Routes = [
  {path:'sellersignup',component: AddSellerComponent},
  {path:'additem',component:  AddItemComponent},
  {path:'itemlist',component: ProductsListComponent},
  {path:'login',component:LoginComponent}
  
  
  


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
