import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiResponse } from './Item'

@Injectable({
  providedIn: 'root'
})
export class SellerserviceService {


  constructor(private http: HttpClient) { }

  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8998/' + 'token/generate-token', loginPayload);
  }

  addSeller (seller: Object): Observable<any> {
    return this.http.post('http://localhost:8998/addseller',seller);
  }
  addItem (item: Object): Observable<any> {
    return this.http.post('http://localhost:9091/additem/1',item);
  }
  getAllItems(): Observable<any> {
    return this.http.get(`http://localhost:9091/getAllItems/1`);
  }
  }

