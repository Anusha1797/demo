export class Seller {
    sellerid: number;
	username: String;
	password: String;
	companyname: String;
    briefaboutcompany: String;
	postaladdress: String;
	website: String;
	emailid: String;
	contactnumber: number
}