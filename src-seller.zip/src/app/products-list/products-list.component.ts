import { Component, OnInit } from '@angular/core';
import { Item } from '../Item';
import { SellerserviceService } from '../sellerservice.service';

@Component({
  selector: 'app-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.css']
})
export class ProductsListComponent implements OnInit {

  item: Item=new Item();
  
  

  constructor(private sellerservice: SellerserviceService) { }

  ngOnInit(): void {
    console.log("Product List Displayed");
    this.sellerservice.getAllItems().subscribe(item=>this.item=item);
  }



}
