export class Item {
    itemid: number;
    price: number;
    itemname: String;
    description: String;
    stocknumber: number;
    remarks: String;
}
export class ApiResponse {

    status: number;
    message: number;
    result: any;
  }
  export class User {

    id: number;
  
  }
  