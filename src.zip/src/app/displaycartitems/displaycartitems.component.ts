import { Component, OnInit } from '@angular/core';
import { cart } from '../cart';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-displaycartitems',
  templateUrl: './displaycartitems.component.html',
  styleUrls: ['./displaycartitems.component.css']
})
export class DisplaycartitemsComponent implements OnInit {

  cartitems: cart=new cart();
  i:any;
  displaycart: any;
  constructor(private sellerservice: SellerServiceService) { }

  ngOnInit() {
    this.reloadcart();
        
  }
  reloadcart(){

    this.sellerservice.getitemByid().subscribe(cartitems=>this.cartitems=cartitems);
  }
 /* displaycart() {
    console.log("displaycartitems");
    

  }*/
  deleteitem(i) {
   console.log("itemdeleted");
   this.sellerservice.deleteitemById(i).subscribe(() => this.reloadcart());

 } 
Incre(displaycart: cart,cartId: number)
{
console.log("incre");
displaycart.numberofitems+=1;
//this.sellerservice.deleteitemById(i).subscribe(() => this.reloadcart());

}
Decre(displaycart: cart,cartId: number)
{
  console.log("decre");
  displaycart.numberofitems-=1;
}


}
