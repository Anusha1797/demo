import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { cart } from './cart';
import { Buyer } from './Buyer';
import { Transactions } from './Transactions';
import { ApiResponse } from './Buyer';


@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
  private baseUrl= 'http://localhost:8998/searchitem';

  constructor(private http: HttpClient) { }

  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:9090/' + 'token/generate-token', loginPayload);
  }

  addBuyer(buyer: Buyer): Observable<any> {
    return this.http.post(`http://localhost:9090/addBuyer`,buyer);
  }

  getItemsByName(name: String): Observable<any> {

    return this.http.get(`${this.baseUrl}/${name}`);
      }

      addtocart(cart: cart): Observable<any> {
        return this.http.post(`http://localhost:8081/addcart/1001`,cart);
      }
       getitemByid(): Observable<any> {
         return this.http.get('http://localhost:8081/getitembyid/1001');
       }
       deleteitemById(cartId: number): Observable<any> {
         return this.http.delete(`http://localhost:8081/deleteById/${cartId}`);
       }
      /* addSeller(seller: Object): Observable<any> {
         return this.http.post('htpp://localhost:9091/addseller',seller);
       }*/
       UpdateCart (cartId:number, cart: cart): Observable<any> {
         console.log("hi");
         return this.http.put(`http://localhost:8081/updatecartbyId/${cartId}`,cart);
       }
      
       checkout(transactions: Transactions): Observable<any> {
        return this.http.post(`http://localhost:8081/checkout/1001`,transactions);
       }
    
    }
    

