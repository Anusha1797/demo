export class Buyer {
	 id: number;
     username: String;
	 password: String;
	 email: String;
	 mobileNumber: number
}

export class ApiResponse {

	status: number;
	message: number;
	result: any;
  }

  export class User {

	Id: number;
  
  }
  
  










