import { Component, OnInit } from '@angular/core';
import { Transactions } from '../Transactions';
import { SellerServiceService } from '../seller-service.service';


@Component({
  selector: 'app-check-out',
  templateUrl: './check-out.component.html',
  styleUrls: ['./check-out.component.css']
})
export class CheckOutComponent implements OnInit {

  transactions: Transactions=new Transactions();

  constructor(private sellerservice: SellerServiceService) { }

  ngOnInit(): void {
  }
  checkout() {
    console.log("checkout performed");
    this.sellerservice.checkout(this.transactions).subscribe(message=>{alert('success');});
  }

}
