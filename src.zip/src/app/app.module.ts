import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ItemdetailsComponent } from './itemdetails/itemdetails.component';
import { DisplaycartitemsComponent } from './displaycartitems/displaycartitems.component';
import { SearchitemComponent } from './searchitem/searchitem.component';
import { BuyerSignupComponent } from './buyer-signup/buyer-signup.component';
import { LoginComponent } from './login/login.component';
import { CheckOutComponent } from './check-out/check-out.component';
import { SellerServiceService } from './seller-service.service';
import { TokenInterceptor } from './Interceptor';
import { PurchaseHistoryComponent } from './purchase-history/purchase-history.component';
 


@NgModule({
  declarations: [
    AppComponent,
    ItemdetailsComponent,
    DisplaycartitemsComponent,
    SearchitemComponent,
    BuyerSignupComponent,
    LoginComponent,
    CheckOutComponent,
    PurchaseHistoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule, 
    ReactiveFormsModule
  ],
  providers: [SellerServiceService,{provide: HTTP_INTERCEPTORS,
  useClass: TokenInterceptor,
  multi: true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
