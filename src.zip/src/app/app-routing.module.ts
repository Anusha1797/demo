import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplaycartitemsComponent } from './displaycartitems/displaycartitems.component';
import { SearchitemComponent } from './searchitem/searchitem.component';
import { BuyerSignupComponent } from './buyer-signup/buyer-signup.component';
import { LoginComponent } from './login/login.component';
import { CheckOutComponent } from './check-out/check-out.component';
import { PurchaseHistoryComponent } from './purchase-history/purchase-history.component';


const routes: Routes = [
 {path:'Shoppingcart',component:DisplaycartitemsComponent},
{path:'searchitem',component: SearchitemComponent},
{path:'Signup',component:BuyerSignupComponent },
{path:'login',component:LoginComponent },
{path:'checkout',component:CheckOutComponent },
{path:'purchase',component:PurchaseHistoryComponent}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
