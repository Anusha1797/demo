import { Component, OnInit, Input } from '@angular/core';
import { Item } from '../Item';
import { cart } from '../cart';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-itemdetails',
  templateUrl: './itemdetails.component.html',
  styleUrls: ['./itemdetails.component.css']
})
export class ItemdetailsComponent implements OnInit {

  constructor(private sellerservice: SellerServiceService) { }
  @Input() item: Item
  cart: cart=new cart()


  ngOnInit(): void {
  }
  //bid:String=localStorage.getItem("id");
  addtocart () {
    console.log("inside cart");
    this.cart.itemid=this.item.itemid;
    this.cart.price=this.item.price;
    this.cart.numberofitems=this.item.stocknumber;
    this.sellerservice.addtocart(this.cart).subscribe(cart=>this.cart=cart);

  }

 
}
