package com.cts.Loader;

/*import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cts.entity.InventoryEntity;
import com.cts.repository.InventoryRepositary;

@Service
public class Loader {
	@Autowired
	 InventoryRepositary inventoryrepository;
	
	@PostConstruct
	public void load() {
		List<InventoryEntity> inventoryList= getList();
		inventoryrepository.save(inventoryList);	
	}
	 public List<InventoryEntity> getList() {
		 List<InventoryEntity> inventoryList= new ArrayList<>();
		 inventoryList.add(new InventoryEntity(1001,"AC",true));
		 inventoryList.add(new InventoryEntity(1002,"Non-AC",false));
		 return inventoryList;
	 }*/
	