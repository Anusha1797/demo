package com.cts.entity;

import javax.persistence.Entity;


import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/*import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;*/


@Entity
/*@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor*/
public   class InventoryEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String roomType;
    boolean isAvailable;
    
   public InventoryEntity() {
   	
    }
   
   public InventoryEntity(int id, String roomType, boolean isAvailable) {
	super();
		this.id = id;
		this.roomType = roomType;
       this.isAvailable = isAvailable;
   }

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getRoomType() {
	return roomType;
}

public void setRoomType(String roomType) {
	this.roomType = roomType;
}

public boolean isAvailable() {
	return isAvailable;
}

public void setAvailable(boolean isAvailable) {
	this.isAvailable = isAvailable;
}
   
    
    
}