package com.cts.exception;

import java.util.Date;


/*import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;*/

/*@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor*/
public class ExceptionResponse {
	
	public String exceptionMessage;
    public Date timestamp;

public ExceptionResponse() {
	
}
public ExceptionResponse(String exceptionMessage, Date timestamp) {
	super();
	this.exceptionMessage = exceptionMessage;
	this.timestamp = timestamp;
}
public String getExceptionMessage() {
	return exceptionMessage;
}
public void setExceptionMessage(String exceptionMessage) {
	this.exceptionMessage = exceptionMessage;
}
public Date getTimestamp() {
	return timestamp;
}
public void setTimestamp(Date timestamp) {
	this.timestamp = timestamp;
}
}

