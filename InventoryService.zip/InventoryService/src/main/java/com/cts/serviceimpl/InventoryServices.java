package com.cts.serviceimpl;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.cts.entity.InventoryEntity;
import com.cts.repository.InventoryRepositary;
import com.cts.service.InventoryService;

@Service
public class InventoryServices implements InventoryService {
	 @Autowired
	private InventoryRepositary inventoryRepositary;
	 
	
	 public Optional<InventoryEntity> checkAvaliability(int id) {
		  return inventoryRepositary.findById(id);
	 }


	@Override
	public InventoryEntity getroom(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public InventoryEntity addroomInventory(InventoryEntity room) {
		// TODO Auto-generated method stub
		return inventoryRepositary.save(room);
	}


	@Override
	public InventoryEntity updateInventory(InventoryEntity updateroom) {
		// TODO Auto-generated method stub
		return inventoryRepositary.save(updateroom);
	}

	
    @Cacheable(value="inventoryservices", key="#roomType")
	public InventoryEntity getinventory(String roomType) {

		return inventoryRepositary.findByroomType(roomType) ;
	}
    
    @PostConstruct
	public void load() {
		List<InventoryEntity> inventoryList= getList();
		inventoryRepositary.save(inventoryList);	
	}
	 public List<InventoryEntity> getList() {
		 List<InventoryEntity> inventoryList= new ArrayList<>();
		 inventoryList.add(new InventoryEntity(1001,"AC",true));
		 inventoryList.add(new InventoryEntity(1002,"Non-AC",false));
		 return inventoryList;
	 }
	

}
