package com.egg.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.egg.model.Items;



@Repository
public interface ItemDao extends JpaRepository<Items, Integer>

{
    @Query(value="FROM Items where item_name like %:name%")
    public List<Items> findByName(@Param("name") String name);
    @Transactional
    @Modifying
    @Query(value="Delete from items where seller_key=:sid",nativeQuery=true)
	public void deletesellerid(int sid);
	//public List<Items> findAllById(int sid);	
    @Query(value="SELECT * From items where seller_key=:sid",nativeQuery=true)
	public List<Items> getAllItems(int sid);
}
