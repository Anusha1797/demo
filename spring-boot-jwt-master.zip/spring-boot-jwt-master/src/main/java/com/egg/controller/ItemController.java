package com.egg.controller;

import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.Items;
import com.egg.service.ItemService;



@CrossOrigin(origins="*")
@RestController
public class ItemController 
{
	@Autowired
	private ItemService service;
	
	/*@RequestMapping("getAllItems/{sid}")
	public List<Items> getAllItems(@PathVariable(value="sellerid") int sid)
	{
		return service.getAllItems(sid);
	}*/
	@RequestMapping("getAllItems/{sid}")
	public List<Items> getAllItems(@PathVariable(value="sid") int sid)
	{
		return service.getAllItems(sid);
	}
	@RequestMapping(value="additem/{sellerid}",method=RequestMethod.POST,produces="application/json")
	public String addItem(@PathVariable(value="sellerid") int sid, @RequestBody Items items)
	{
		 service.addItem(items,sid);
		 return "Item Added";
	}
	@RequestMapping(value="deleteitem/{sellerid}")
	public void deleteitem(@PathVariable(value="sellerid") int sid)
	{
		service.deleteitem(sid); 
	}
	
	
	//Searching item by item name
	@RequestMapping(value="searchitem/{itemname}")
	public List<Items> searchforitem(@PathVariable(value="itemname") String name)
	{
		return service.searchforitem(name);
	}
		
	
	@RequestMapping(value="updateitem/{sid}")
	public Items updateitem(@PathVariable(value="sid") int sid, @RequestBody Items items)
	{
		return service.updateitem(sid, items);
	}
	
	
	
}
		






