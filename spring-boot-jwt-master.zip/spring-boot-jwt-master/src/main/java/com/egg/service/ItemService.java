package com.egg.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.ItemDao;
import com.egg.dao.SellerDao;
import com.egg.model.Items;
import com.egg.model.Seller;



@Service
public class ItemService 
{
	@Autowired
	private ItemDao itemdao;
	@Autowired
	private SellerDao sellerdao;

	/*public List<Items> getAllItems(int sid) 
	{
		return itemdao.findAllById(sid) ;
	}*/

	public Items addItem(Items items, int sid)
	{
		Seller seller= sellerdao.getOne(sid);
		items.setSellerid(seller);
		return itemdao.save(items);
	}

	public List<Items> searchforitem(String name) 
	{
		return itemdao.findByName(name);
	}

	public void deleteitem(int sid)
	{
		
		itemdao.deletesellerid(sid);;
	}
    
	public Items updateitem(int sid,Items items)
	{
		Items item=itemdao.getOne(sid);
		int price=items.getPrice();
		item.setPrice(price);
		return itemdao.save(item);
	}

	public List<Items> getAllItems(int sid) {
		
		return itemdao.getAllItems(sid);
	}
	
	

}



